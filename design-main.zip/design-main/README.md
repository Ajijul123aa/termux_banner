# design

Installation:-

pkg up -y

pkg in git python2 -y

git clone https://github.com/BDhaCkers009/design

cd design

python2 design.py
